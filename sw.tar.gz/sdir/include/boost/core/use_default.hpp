/*
Copyright 2019 Glen Joseph Fernandes
(glenjofe@gmail.com)

Distributed under the Boost Software License, Version 1.0.
(http://www.boost.org/LICENSE_1_0.txt)
*/
#ifndef BOOST_CORE_USE_DEFAULT_HPP
#define BOOST_CORE_USE_DEFAULT_HPP

namespace boost {

struct use_default { };

} /* boost */

#endif
